#With this test image you can check the blur and focus of the camera
#Use it everytime the camera needs to be used
from picamera import PiCamera
from time import sleep

#Detects the camera connected on the port of the raspberry pi
camera = PiCamera()
camera.rotation=180 #Rotates the camera if needed, if not takethis line off
camera.start_preview() #Starts a preview on a monitor conected to the rasp

sleep(15)
camera.capture('/home/pi/Desktop/test.jpg')#Takes an image if theres no monitor

camera.stop_preview()#Stops the camera