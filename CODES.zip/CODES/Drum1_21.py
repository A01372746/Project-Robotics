'''
from picamera import PiCamera
from time import sleep
'''
import cv2
import numpy as np
from matplotlib import pyplot as plt
import bluetooth

host,port = "", 1

server = bluetooth.BluetoothSocket(bluetooth.RFCOMM)

try:
    server.bind((host, port))
    print("Conexion exitosa")
except:
    print("Falla en el conexión")

server.listen(1)
cliente, direccion = server.accept()
print("Conectado a:", direccion)
print("Cliente:", cliente)


try:
    while True:
        '''
        camera = PiCamera()

        camera.start_preview()
        sleep(5)
        camera.capture('/home/pi/Desktop/DrumPython/Drum.jpg')
        camera.stop_preview()
        '''
        if dato != d:
            img = cv2.imread('/home/pi/Desktop/DrumPython/Drum.jpg')
            igc = cv2.medianBlur(img,5)
            cimg = cv2.cvtColor(igc,cv2.COLOR_GRAY2BGR)
            
            #Values from the DrumSet Code
            mi,ma=10,30

            circles = cv2.HoughCircles(igc,cv2.HOUGH_GRADIENT,1,20,
                                        param1=50,param2=30,minRadius=mi,maxRadius=ma)
            coor = []
            circles = np.uint16(np.around(circles))
            if len(circles) != 0:
                for i in circles[0,:]:
                    # draw the outer circle
                    cv2.circle(cimg,(i[0],i[1]),i[2],(0,255,0),2)
                    # draw the center of the circle
                    cv2.circle(cimg,(i[0],i[1]),2,(0,0,255),3)
                    #Transforms the pixel coordinates to cm
                    k0,k1  = (i[0]*2.54/96),(i[1]*2.54/96)
                    #Transforms the code coordinates to real coordinates
                    k0,k1 = (k0+65+70)/1000,(k1+65+70)/1000
                    coor.append((k0,k1))

                print(coor)
            else:
                print('No hay barriles')
        else:
            print('Pasando al siguiente barril')
            dato=='r'

except KeyboardInterrupt:
    client.close()
    server.close()