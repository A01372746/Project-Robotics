Hello!
Welcome to the manual of this project, here are the specifications
you need to know about how to use every part of this project and how
they work.

First we need to set our camera on a tall place that can go from 1.2m 
to 2m.

Then we need to set up our camara blur and opacity, with the CameraSet.py 
we can check on the camera opacity by taking photos. If the image is blured 
then give a turn to the right until the blur is gone.

Third step, we need to set what kind of drum or the distance between the drums
and the camera is. For this we have the DrumSet.py (Note:If the camera isnt moving
and want to test the code with the camera, take out the coment section -'''- of line
1,4,8 and 15.)

Depending on the height on wich the camera is set, you should use the next values:
	Height=2m------->mi=0, ma=15 (For 4 drums)
	Height=1.5m-----> mi=10, ma=30  or mi= 20, ma=40 (At least 2 drums)
	Height=1.2m------> mi=40, ma=60 (Only for one drum)
If the height is more than 2m we recomend to not change the numbers and
if theres more circles detected than the whole, recomendation is to check the i[2] value.
The Height is the distance between th camera and the drum
A height less than 1.2m isnt suitable for the system.
For more presition, keep the minimum for each high and chage de max with the i[2] value.

Now that everything is set up to optimal performance,we can run the Drum1_3.py code, which 
simulates the whole working project if it was connected with a robot(Note: The bluetooth module stoped
working, since that happend we had to simulate the comunication. If the comunication is necesary
check code Drum1_21.py)

