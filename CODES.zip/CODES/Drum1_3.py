'''
from picamera import PiCamera
from time import sleep
'''
import cv2
import numpy as np
from matplotlib import pyplot as plt

'''
camera = PiCamera()

camera.start_preview()
sleep(5)
camera.capture('/home/pi/Desktop/DrumPython/Drum.jpg')
camera.stop_preview()
'''
for i in range(2,5):
    img = cv2.imread('/home/pi/Desktop/DrumPython/Drum%s.jpeg'%i,0)
    igc = cv2.medianBlur(img,5)
    cimg = cv2.cvtColor(igc,cv2.COLOR_GRAY2BGR)
                
    #Values from the DrumSet Code
    mi,ma=10,30

    circles = cv2.HoughCircles(igc,cv2.HOUGH_GRADIENT,1,20,
                                        param1=50,param2=30,minRadius=mi,maxRadius=ma)
    dato=''
    coor = []
    circles = np.uint16(np.around(circles))
    while dato != 'd':
        if len(circles)!=0:
            for i in circles[0,:]:
                # draw the outer circle
                cv2.circle(cimg,(i[0],i[1]),i[2],(0,255,0),2)
                # draw the center of the circle
                cv2.circle(cimg,(i[0],i[1]),2,(0,0,255),3)
                #Transforms the pixel coordinates to cm
                k0,k1  = (i[0]*2.54/96),(i[1]*2.54/96)
                #Transforms the code coordinates to real coordinates
                k0,k1 = (k0+45)/100,(k1+70)/100
                coor.append((k0,k1))

            images = [img, cimg]
            titles = ['Original Image', 'Hole Detection']

            plt.subplot(2,1,1),plt.imshow(images[0],'gray')
            plt.title(titles[0]), plt.xticks([]), plt.yticks([])
            plt.subplot(2,1,2),plt.imshow(images[1],'gray')
            plt.title(titles[1]), plt.xticks([]), plt.yticks([])
                
            print(coor)
            plt.show()
            dato=input("Los barriles se encuentran en las siguientes coordenadas: ")
        else:
            print('No se detecto ningun barril')
            
