'''
from picamera import PiCamera
from time import sleep
'''
import cv2
import numpy as np
from matplotlib import pyplot as plt
'''
camera = PiCamera()

camera.start_preview()
sleep(5)
camera.capture('/home/pi/Desktop/DrumPython/test.jpg')
camera.stop_preview()
'''
img = cv2.imread('/home/pi/Desktop/DrumPython/test.jpg',0)
igc = cv2.medianBlur(img,5)
cimg = cv2.cvtColor(igc,cv2.COLOR_GRAY2BGR)

mi,ma=20,40
circles = cv2.HoughCircles(igc,cv2.HOUGH_GRADIENT,1,20,
                            param1=50,param2=30,minRadius=mi,maxRadius=ma)

coor = []
circles = np.uint16(np.around(circles))
for i in circles[0,:]:
    # draw the outer circle
    cv2.circle(cimg,(i[0],i[1]),i[2],(0,255,0),2)
    # draw the center of the circle
    cv2.circle(cimg,(i[0],i[1]),2,(0,0,255),3)
    coor.append((i[0],i[1],i[2]))

images = [img, 0, igc,
          igc, 0, cimg]
titles = ['Original Image','Histogram',"Gausian Filtered Image",
          "Gaussian Filtered Image", 'Histogram', 'Hole Detection']

for i in range(2):
    plt.subplot(3,3,i*3+1),plt.imshow(images[i*3],'gray')
    plt.title(titles[i*3]), plt.xticks([]), plt.yticks([])
    plt.subplot(3,3,i*3+2),plt.hist(images[i*3].ravel(),256)
    plt.title(titles[i*3+1]), plt.xticks([]), plt.yticks([])
    plt.subplot(3,3,i*3+3),plt.imshow(images[i*3+2],'gray')
    plt.title(titles[i*3+2]), plt.xticks([]), plt.yticks([])

plt.show()
print(coor)
    